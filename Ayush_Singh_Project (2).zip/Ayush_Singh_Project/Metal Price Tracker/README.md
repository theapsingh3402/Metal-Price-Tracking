# Metals Price Tracker

A React web app to track **live prices of Gold, Silver, and Platinum** with support for multiple currencies (USD, INR, EUR ).  
Includes historical data, open/close prices, and interactive charts.

---

## Key Features
- Live prices updated every 60 seconds.
- Current **system clock** and **last updated time** shown.
- Click on any metal to view:
  - Historical open/close prices.
  - Interactive graph with 7-day, 1-month, 1-year ranges.
- Currency selector (one currency at a time).

---

## Installation & Setup

1. **Unzip this project**  
   ```bash
   unzip metals-price-tracker.zip
   cd metals-price-tracker
   ```

2. **Install dependencies**  
   ```bash
   npm install
   ```

3. **Start development server**  
   ```bash
   npm run dev
   ```

4. Open the local URL in your browser (usually `http://localhost:5173/`).

---

## API Information
The project fetches live metal prices from a metals API.  
You will need to add your own API key in `api.ts` (or whichever API service you choose).

Example API call structure:
```ts
export const fetchMetalPrices = async () => {
  const res = await fetch(`https://metals-api.com/api/latest?access_key=YOUR_API_KEY&symbols=XAU,XAG,XPT`);
  const data = await res.json();
  return {
    gold: data.rates.XAU,
    silver: data.rates.XAG,
    platinum: data.rates.XPT
  };
};
```

---

## Build for Production
```bash
npm run build
npm run preview
```

---

## Key Notes
- Replace `YOUR_API_KEY` in `api.ts` with your actual API key.  
- Ensure you have **Node.js (>=16)** installed.  

---

Made by Ayush Prakash Singh using React + Tailwind


---
