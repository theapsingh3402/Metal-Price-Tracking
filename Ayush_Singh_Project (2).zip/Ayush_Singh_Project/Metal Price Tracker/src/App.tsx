import { Routes, Route } from "react-router-dom";
import LiveMetals from "./components/LiveMetals";
import MetalDetails from "./components/MetalDetails";

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<LiveMetals />} />
      <Route path="/metal/:name" element={<MetalDetails />} />
    </Routes>
  );
};

export default App;