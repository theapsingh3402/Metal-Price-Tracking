// src/api.ts
import axios from "axios";

const API_KEY = "test-api-key-12345"; //It's a test key

export const fetchMetalPrices = async (currency: string) => {
  const response = await axios.get("https://metalapi.com/api/v1/latest", {
    headers: { Authorization: `Bearer ${API_KEY}` },
    params: { currency },
  });
  return response.data.data; 
};

export const fetchMetalHistory = async (metal: string, currency: string, range: string) => {
  const response = await axios.get("https://metalapi.com/api/v1/history", {
    headers: { Authorization: `Bearer ${API_KEY}` },
    params: { metal, currency, range },
  });
  return response.data.data; 
};
