import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { useState, useEffect } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";
import { fetchMetalHistory } from "../api";

const MetalDetails = () => {
  const { name } = useParams<{ name: string }>();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState<"7d" | "1m" | "1y">("7d");
  const [currency, setCurrency] = useState(searchParams.get("currency") || "USD");

  useEffect(() => {
    const getHistory = async () => {
      try {
        setLoading(true);
        const data = await fetchMetalHistory(name || "gold", range, currency);
        setHistory(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    getHistory();
  }, [name, range, currency]);

  useEffect(() => {
    setSearchParams({ currency });
  }, [currency]);

  if (loading) return <div className="p-4">Loading history...</div>;

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <button
        onClick={() => navigate("/")}
        className="mb-4 px-3 py-1 bg-gray-200 rounded"
      >
        ⬅ Back
      </button>

      <h2 className="text-xl font-bold capitalize">{name} Price History</h2>

      {/* Currency selector */}
      <div className="mt-2">
        <label className="mr-2">Currency:</label>
        <select
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
          className="border rounded p-1"
        >
          <option value="USD">USD</option>
          <option value="INR">INR</option>
          <option value="EUR">EUR</option>
          <option value="GBP">GBP</option>
          <option value="JPY">JPY</option>
        </select>
      </div>

      {/* Range selector */}
      <div className="flex gap-3 mt-3">
        {["7d", "1m", "1y"].map((r) => (
          <button
            key={r}
            onClick={() => setRange(r as any)}
            className={`px-3 py-1 rounded ${
              range === r ? "bg-blue-500 text-white" : "bg-gray-200"
            }`}
          >
            {r === "7d" ? "7 Days" : r === "1m" ? "1 Month" : "1 Year"}
          </button>
        ))}
      </div>

      {/* Open/Close List */}
      <ul className="mt-3">
        {history.slice(-5).map((day, idx) => (
          <li key={idx}>
            {day.date}: Open {day.open} – Close {day.close} {currency}
          </li>
        ))}
      </ul>

      {/* Graph */}
      <div className="mt-5 h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={history}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="close" stroke="#8884d8" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default MetalDetails;