import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { fetchMetalPrices } from "../api";

const LiveMetals = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [metals, setMetals] = useState<any>({});
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const [currency, setCurrency] = useState(searchParams.get("currency") || "USD");

  const fetchData = async () => {
    try {
      setLoading(true);
      const data = await fetchMetalPrices(currency);
      setMetals(data);
      setLastUpdated(new Date().toLocaleString());
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 60000);
    return () => clearInterval(interval);
  }, [currency]);

  useEffect(() => {
    setSearchParams({ currency });
  }, [currency]);

  const date = new Date();

  if (loading) return <div className="p-4">Loading prices...</div>;

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Live Precious Metals Prices</h1>
      <p>Date: {date.toLocaleDateString()} Time: {date.toLocaleTimeString()}</p>
      <div className="mt-3">
        <label className="mr-2">Currency:</label>
        <select
          value={currency}
          onChange={(e) => setCurrency(e.target.value)}
          className="border rounded p-1"
        >
          <option value="USD">USD</option>
          <option value="INR">INR</option>
          <option value="EUR">EUR</option>
          <option value="GBP">GBP</option>
          <option value="JPY">JPY</option>
        </select>
      </div>

      <ul className="mt-4 space-y-2">
        {["gold", "silver", "platinum"].map((metal) => (
          <li
            key={metal}
            className="p-3 bg-white rounded shadow cursor-pointer hover:bg-gray-100"
            onClick={() => navigate(`/metal/${metal}?currency=${currency}`)}
          >
            {metal.toUpperCase()}: {metals[metal]?.[currency]} {currency}/oz
          </li>
        ))}
      </ul>

      <p className="mt-4 text-sm text-gray-600">
        Last updated: {lastUpdated}
      </p>
    </div>
  );
};

export default LiveMetals;